#include "mainwindow.h"
#include "./ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()

{
     QString inputString = ui->lineEdit->text();

    if (isPalindrome(inputString.toStdString()))
         ui->label_2->setText(ui->label_2->text()="Це паліндром");
    else
         ui->label_2->setText(ui->label_2->text()="Це не паліндром");
}


